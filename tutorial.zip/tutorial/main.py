# !/usr/bin/python
# -*- coding: utf-8 -*-
"""
    gsliu 2017-03-09
    
"""

from scrapy import cmdline


cmdline.execute("scrapy crawl test".split())